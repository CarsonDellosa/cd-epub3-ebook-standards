atom.declare('Submarine.Model', App.Element, {
    model : null,
    network : null,
    path : new Path(),
    area : new Path(),
    step : 0,
    history : [],
    time : new Date().getTime(),
    network_interval : 200,
    network_buff_size : 5,
    
    load : function (render) {
        this.model = new Submarine(render);
        this.model.load();
        this.network = new GraphNet(this, this.network_buff_size, server_url_in);
    },
    
    save_history : function(status) {
        //this.history.push(status);  
    },
    
    onUpdate: function () {
        var t = new Date().getTime();
        
        if (t - this.time > this.network_interval) {
            var deep = (this.model.deep - sub_position.min) / (sub_position.max - sub_position.min);
            
            this.network.send_data(deep);
            this.time = t;
            
            atom.dom('#H').text(Math.round(300 * deep));
        }
        
        this.redraw();
    },
    
    renderTo : function (ctx) {

        ctx.clearAll();

        this.step++;
        var waves = this.model.deep; //+ Math.sin(this.step * 0.1) * 5;
        
        this.shape.center.y = waves;
        
        ctx.drawImage({
            image : this.model.get_frame(),
            from : new Point(canvas_size.width / 2 - sub_size.width / 2, waves),
        });

            var points = [];
            var water_line = [];
            var pts = this.model.get_points();
    
            for (var i = 0; i < pts.length; i++) {
                var deep = waves / 5.5;   
                
                var point = [pts[i].screen.x + canvas_size.width / 2, pts[i].screen.y + waves + sub_size.height / 2];
                
                points[points.length] = point;
                
                if (pts[i].world.y > deep - 20) {
                    water_line[water_line.length] = point;
                }

            }
    
            var pl = points.length,
                wll = water_line.length;
                
            this.area = new Path();
            
            if (pl > 0) {

                if (wll > 0) {
                    
                    /*
                    for (var i = 1; i < wll; i++) {
                        ctx.fill(new Circle(water_line[i][0], water_line[i][1], 3), 'green');
                    }
                    */
                    
                    
                    var shell = get_shell(water_line); 
                    var white = new Path();
                    
                    white.moveTo(new Point(shell[0][0], shell[0][1]));
                    
                    for (var i = 0; i < shell.length; i++) {
                        white.lineTo(new Point(shell[i][0], shell[i][1]));
                        //////////////////////
                        //ctx.fill(new Circle(shell[i][0], shell[i][1], 3), 'blue');
                    }
                    
                    white.lineTo(new Point(shell[0][0], shell[0][1]));
                    
                    //ctx.stroke(white, 'white');
                    
                    this.area = white;
                    
                    
                    //this.area = new Circle(canvas_size.width / 2, canvas_size.height / 2, (sub_size.width + sub_size.height) / 4);
                }
                
                
                var body = get_shell(points);
    
                this.path = new Path();
                
                this.path.moveTo(new Point (body[0][0], body[0][1]));
                    
                for (var i = 1; i < body.length; i++) {
                    this.path.lineTo(new Point (body[i][0], body[i][1]));
                }
                    
                this.path.lineTo(new Point (body[0][0], body[0][1]));
                
                /*
                this.path = new Path();
                
                this.path.moveTo(new Point (points[0][0], points[0][1]));
                    
                for (var i = 1; i < pl; i++) {
                    this.path.lineTo(new Point (points[i][0], points[i][1]));
                }
                    
                this.path.lineTo(new Point (points[0][0], points[0][1]));
                */
            }

        if (app.wireframe) {
            ctx.stroke(this.path, "green");
        }

        //controller.stats.update();
        
    },
    
    set_angle : function (delta) {
        this.model.set_angle(delta);
    },
    
    get_angle :function () {
        return this.model.angle;  
    },
    
    up_down : function (delta) {
        this.model.up_down(delta);
    },
    
    get_points : function (angle) {
        return this.model.get_points(angle);  
    },
    
    load_frames : function () {
        this.model.load_frames();
    }
    
});

atom.declare('Submarine.Water', App.Element, {
    submarine_model : null,
    
    load : function (model) {
        this.submarine_model = model;
    },
    
    
    onUpdate : function () {
        this.redraw();
    },
    
    
    renderTo : function (ctx) {

        ctx.set({
            fillStyle : "rgba(0, 0, 200, 0.5)",
            strokeWidth : 3
        })

        ctx.fill(this.shape);
        /*
        var poly = new Polygon([
            [canvas_size.width / 2 - sub_size.width / 2, canvas_size.height / 2 - sub_size.height / 2],
            [canvas_size.width / 2 + sub_size.width / 2, canvas_size.height / 2 - sub_size.height / 2],
            [canvas_size.width / 2 + sub_size.width / 2, canvas_size.height / 2 + sub_size.height / 2],
            [canvas_size.width / 2 - sub_size.width / 2, canvas_size.height / 2 + sub_size.height / 2],
        ]);
        
               
        poly.rotate((-this.submarine_model.get_angle()).degree(), poly.center)
        
        ctx.stroke(poly);
        */
        
        ctx.set({
            fillStyle : "rgba(0, 0, 200, 1)",
        })
   
        ctx.clear(this.submarine_model.area);
    }

});


        
function get_shell(area_points) {
    
    function rotate (a, b, c) {
        if (!a || !b || !c) {
            return 0;
        }
        return (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    }
   
    var area_length = area_points.length; 
            
    for (var i = 1; i < area_length; i++) {
        var j = i;
                    
        while (j >= 1 && rotate(area_points[0], area_points[j-1], area_points[j]) > 0) {
            var p = area_points[j];
            area_points[j] = area_points[j-1];
            area_points[j-1] = p;
            j -= 1;
        }
    }
            
    var shell = [area_points[0], area_points[1]];
                                
    for (var i = 1; i < area_length; i++) {
                
        if (rotate(shell[shell.length - 2], shell[shell.length - 1], area_points[i]) == 0) {
            shell.pop();
        }

        while (rotate(shell[shell.length - 2], shell[shell.length - 1], area_points[i]) > 0) {
            shell.pop();
        }
                
        shell.push(area_points[i]);
    }
            
    return shell;
            
}





