atom.declare('Submarine.Graph', App.Element, {
    network : null,
    history : [],
    time : new Date().getTime(),
    network_interval : 1000,
    
    load : function () {
        this.network = new GraphNet(this, 1, server_url_out);  
    },
    
    save : function (status, self) {
        self.network.send_data(status);
        self.redraw();
    },
    
    onUpdate: function () {
        var t = new Date().getTime();
        
        if (t - this.time > this.network_interval) {
            this.network.send_data(t);
            this.time = t;
        }
    },
    
    save_history : function(status) {
        /*
        for (var i = 0; i < status.length; i++) {
            this.history.push(status[i]);
            this.redraw();
        }
        */
        this.history.push(status);
        this.redraw();
    },
    
    renderTo : function (ctx) {
        //ctx.stroke(this.shape);
        /*
        var graph = new Path();

        graph.moveTo(new Point(0, 0));
        
        var hl = this.history.length - 1;
        
        for (var i = 0; i < 200; i++) {
            if (this.history[hl - i]) {
                var position = graph_size.height - this.history[hl - i] * graph_size.height;
                graph.lineTo(new Point (graph_size.width / 200 * i, position));
            } else {
                var position = graph_size.height - this.history[hl - i - 1] * graph_size.height;
                graph.lineTo(new Point (graph_size.width, position));
            }
        }
        
        
        
        graph.lineTo(new Point (graph_size.width, graph_size.height));
        graph.lineTo(new Point (0, graph_size.height));

        ctx.stroke(graph, 'green');
        */
        
        var hl = this.history.length;
        
        if (hl > 1) {
            var p = Math.round(this.history.pop() * 300);
            atom.dom('#P').text(p);
            var label = '';
            if (p < 50) {
                label = 'Deeper';
                atom.dom('.elephant').css('visibility', 'hidden');
            } else
                if (p > 55) {
                    label = 'Shallower';
                    atom.dom('.elephant').css('visibility', 'hidden');
                } else {
                    label = 'Right';
                    atom.dom('.elephant').css('visibility', 'visible');
                }
            atom.dom('#info-label').text(label);
        }
        //atom.dom('#P').text(Math.round(this.history[hl - 1] * 300));
    }
});












