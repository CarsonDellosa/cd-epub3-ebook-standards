var area_width = atom.dom('#area').elems[0].clientWidth < 960 / 3 ? 960 : atom.dom('#area').elems[0].clientWidth;

function clientHeight(){
    return document.documentElement.clientHeight == 0 ? document.body.clientHeight : document.documentElement.clientHeight;
}

var canvas_size = {
    width : 800,
    height : 1100 - atom.dom('.footer').elems[0].clientHeight - atom.dom('.head-panel').elems[0].clientHeight,//clientHeight() - 60//area_width / 2,
}

var graph_size = {
    width : 0,//area_width,
    height : 0//area_width / 7
}

var sub_size = {
    width : canvas_size.height / 3.5,
    height : canvas_size.height / 3,
    z : 150,
    distance : 25
}

var sub_position = {
    max : canvas_size.height / 8 * 6,
    min : canvas_size.height / 8
}

var app = {
    webgl : false,
    model : false,
    wireframe : false,
    full_wireframe : true,
}

var domain = 'ieee2.competentum.ru';
//var domain = 'ieee.competentum.ru';

//var domain = 'sub.loc';
//var domain = 'cors.loc';

var server_url_in = 'http://' + domain + '/server/in.php';
var server_url_out = 'http://' + domain + '/server/out.php';

atom.declare('Submarine.Controller', {

        stats : null,
        render : null,
    
        dipping : false,
        loaded : false,
        selected : false,
        
        /////////////////////////////////////////////////////////////////

        sub_layer : null,
        water_layer : null,
        load_layer : null,
        mouse_handler : null,
        
        submarine_model : null,
        water_model : null,

        /////////////////////////////////////////////////////////////////
        
        graph_context : null,
        graph_layer : null,
        graph_model : null,
        
        /////////////////////////////////////////////////////////////////
    
    initialize : function () {
  
        this.render = new Render3D(sub_size.width, sub_size.height, sub_size.z, sub_size.distance);
        
        //////////////////////////////////////////////////////////////
        
        this.graph_context = new LibCanvas.App({
            appendTo : '#graph',
            size : [graph_size.width, graph_size.height]
        });
        
        this.graph_layer = this.graph_context.createLayer({invoke : true, intersection : 'manual', zIndex : 0});
        
        this.graph_model = new Submarine.Graph(this.graph_layer, {
            shape : new Rectangle(0, 0, graph_size.width, graph_size.height)
        })
        
        this.graph_model.load();
        

        //////////////////////////////////////////////////////////////
        
        this.sub_context = new LibCanvas.App({
            appendTo : '#area',
            size : [canvas_size.width, canvas_size.height]
        });
            
        this.sub_layer = this.sub_context.createLayer({invoke : true, intersection : 'manual', zIndex : 0});
        this.water_layer = this.sub_context.createLayer({invoke : true, intersection : 'manual', zIndex : 1});
        this.load_layer = this.sub_context.createLayer({invoke : false, intersection : 'manual', zIndex : 2});

        this.load_layer.ctx.fillAll('white');
        this.write_preload_text(this.load_layer.ctx, 'LOADING');

        this.submarine_model = new Submarine.Model(this.sub_layer, {
            shape: new Circle(canvas_size.width / 2 + sub_size.width / 2,
                              canvas_size.height / 2 + sub_size.height / 2,
                              (sub_size.width + sub_size.height) / 2),
        });
        
        this.water_model = new Submarine.Water(this.water_layer, {
            shape : new Rectangle(0, 0, canvas_size.width, canvas_size.height)    
        });
        
        this.water_model.load(this.submarine_model);

        this.submarine_model.load(this.render);
        
        var self = this;

        var timer = setInterval(function () {
            //self.render.update();
            if (loader.is_load()) {
                clearInterval(timer);
                self.submarine_model.load_frames();
                self.load_layer.hide();
                //self.sub_layer.redrawAll();
            }
        }, 1000 / 250);
        
        
        
        var mouse = new LibCanvas.Mouse(this.sub_context.container.bounds);
        this.mouse_handler = new LibCanvas.App.MouseHandler({app: this.sub_context, mouse: mouse});
        
        //this.init_stats();
        this.init_buttons();
        this.init_events();
        //this.init_graph(this);

    },
    
    write_preload_text : function (ctx, text) {
        ctx.font="50px Verdana";
        ctx.fillText(text, canvas_size.width / 2 - sub_size.width / 2, canvas_size.height / 2);
    },

    init_events : function () {
                       
            var mouse_down = false,
                delta_y, last_y, delta_x, last_x;
            
            var el = atom.dom('#area');
            
            var self = this;
            
            var down = function (e) {
                mouse_down = true;
                last_y = e.pageY;
                last_x = e.pageX;
            }
            
            var move = function (e) {
                if (mouse_down) {
                    delta_y = last_y - e.pageY;
                    delta_x = last_x - e.pageX;
                        if (self.dipping && self.selected) {

                        } else {
                            var i = delta_x > 0 ? -1 : 1;
                            self.submarine_model.set_angle(i);
                            //self.sub_layer.redrawAll();
                        }
                    
                    last_x = e.pageX;
                    last_y = e.pageY;
                }
            }
            
            var up = function (e) {
                mouse_down = false;
                self.selected = false;
            }
            
            el.addEvent({'mousedown' : down});
            el.addEvent({'mousemove' : move});
            el.addEvent({'mouseup' : up});
            el.addEvent({'mouseout' : up});
         
        this.mouse_handler.subscribe(this.submarine_model);
            
        this.submarine_model.events.add('mousemove', function (e) {
            if (this.path.hasPoint(new Point(e.layerX, e.layerY))) {
                if (mouse_down) {
                    self.selected = true;
                }
            }
            
            if (self.dipping && self.selected) {
                delta_y = last_y - e.pageY;
                self.submarine_model.up_down(delta_y);
            }
        });
        
        this.submarine_model.events.add('mouseleave', up);
            
            
    },
        
    init_buttons : function () {
        atom.dom('#up-down').addEvent({'click' : function () {
            controller.dipping = !controller.dipping;
        }});
    },
        
    init_graph : function (self) {
        setInterval(function () {
            self.graph_model.save(self.submarine_model.model.deep, self.graph_model);
        }, 1000 / 5);
            
    },
        
    init_stats : function () {
        this.stats = new Stats();
        this.stats.domElement.style.position = 'fixed';
        this.stats.domElement.style.top = '0px';
        document.body.appendChild(this.stats.domElement);
    }

});

function iframe_msg(msg) {
    console.log(msg);
}


 

