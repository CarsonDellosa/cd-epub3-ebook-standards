<?php
    include 'headers.php';

    $queue = null;
    
    if (isset($_SESSION['queue'])) {
        $queue = unserialize($_SESSION['queue']);
    } else {
        $queue = array();        
    }
    
    if (count($queue) > 0) {
        $response = array();
                
        for ($i = 0; $i < count($queue); $i++) {
            
            $result = json_decode(array_shift($queue));
            
            foreach ($result as $r) {
                $p = ($r * 0.3048) * 1000 * 9.81 / 6894.7567;
                 
                $response[] = $p;
            }
            
            //$response[] = $result;

        }
        
        echo json_encode($response);
        
        unset($_SESSION['queue']);
    } else {
        echo "[]";
    }
?>