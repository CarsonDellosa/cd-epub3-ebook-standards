function Render3D (w, h, z, f) {
            
    var fov = f,
        width = w,
        height = h, 
        aspect = width / height,
        near = 1,
        far = 1000,
        angle = 0,
        position_z = z;
                
        var render, camera, scene;
            
        create_render();      
        load();
            
        function create_render() {
            if (Detector.webgl && app.webgl)
                    render = new THREE.WebGLRenderer({antialias: true});
                else
                    render = new THREE.CanvasRenderer({antialias: true});
            camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
            scene = new THREE.Scene();
        }
            
        this.update = function() {
            update();
        }
        
        this.project = function () {
            
            function get_points_obj (v) {
                return {
                    world : {
                        x : Math.round(v.positionWorld.x),
                        y : Math.round(v.positionWorld.y),
                        z : Math.round(v.positionWorld.z),
                    },
                    
                    screen : {
                        x : Math.round(v.positionScreen.x * (width / 2)),
                        y : Math.round(v.positionScreen.y * (height / 2) * -1)
                    }
                }
            }
            
            var projector = new THREE.Projector();
 
            var data = projector.projectScene(scene, camera, true);
            
            var el = data.elements.length;
            
            var points = [];
            
            for (var i = 0; i < el; i++) {
                
                points[points.length] = get_points_obj(data.elements[i].v1); 

                if (app.full_wireframe) {
                    points[points.length] = get_points_obj(data.elements[i].v2); 
                    points[points.length] = get_points_obj(data.elements[i].v3); 
                }
            }
            
            return points;
        }
        
        function update () {
            render.clear();
            render.render(scene, camera);
        }
            
        function load() {
            render.setSize(width, height);
            set_camera(1);
        }
            
        function set_camera (i) {
            angle += Math.abs(i) * Math.PI / 180;
            camera.position.set(Math.sin(angle) * position_z, position_z, Math.cos(angle) * position_z * i);
            camera.lookAt(scene.position);
        }
            
        this.rotate_camera = function (i) {
            set_camera(i);
        };
            
        this.camera = function () {
            return camera;
        }
            
        this.scene = function () {
            return scene;
        }
            
        this.render = function () {
            return render;
        }
        
        this.unproject = function (vector) {
            var projector = new THREE.Projector();
            return projector.unprojectVector(vector, camera);
        }

}

