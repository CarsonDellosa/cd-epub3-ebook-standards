<?php
    include 'headers.php';
    
    $input = file_get_contents("php://input");
    
    $queue = null;
    
    if (isset($_SESSION['queue'])) {
        $queue = unserialize($_SESSION['queue']);
    } else {
        $queue = array();        
    }
    
    array_push($queue, $input);
    
    $_SESSION['queue'] = serialize($queue);

    /*
    if ($_SESSION['queue']->count() > 0) 
        echo $_SESSION['queue']->dequeue();
    else echo "null";
    */

    echo $input;
 
?>
