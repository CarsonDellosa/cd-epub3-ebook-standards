<?php

    include 'headers.php';
    
    $input = file_get_contents("php://input");
    
    $file = 'model.json';
    
    file_put_contents($file, $input);