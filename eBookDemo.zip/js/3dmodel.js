function Submarine3DModel() {
    var model, scene;
    
    function draw_model(path, scale) {

        var texture_loader = new THREE.ImageLoader();
        
        var body_texture = new THREE.Texture();         
        texture_loader.addEventListener('load', function (e) {
            body_texture.image = e.content;
            body_texture.needsUpdate = true;

	    ////////////////
	    loader.texture = true;
        })
        
        texture_loader.load('img/floor.jpg');
        
        var sub_geometry_loader = new THREE.JSONLoader(),
        sub_material = new THREE.MeshBasicMaterial({ map: body_texture, morphTargets: true, overdraw : true });

        sub_geometry_loader.load(path, function (g) {
            model = new THREE.Mesh(g, sub_material);
            model.scale.x = scale;
            model.scale.y = scale;
            model.scale.z = scale;
            model.name = 'submarine';
	    model.position.y = -20;
	    scene.add(model);
	    
	    /////////////////////
	    loader.model = true;
        });

    }
    
    function draw_submarine() {
        var texture_loader = new THREE.ImageLoader();
        
        var body_texture = new THREE.Texture();         
        texture_loader.addEventListener('load', function (e) {
            body_texture.image = e.content;
            body_texture.needsUpdate = true;
            app.loaded = true;

	    ///////////////////////
	    
	    loader.texture = true;
        })
        
        texture_loader.load('img/floor.jpg');
        
        var sub_body_geometry = new THREE.CylinderGeometry(20, 20, 40, 15, 4, false),
            sub_head_geometry = new THREE.CylinderGeometry(7, 10, 15, 10, 5, false);
                
        var sub_body_material = new THREE.MeshBasicMaterial({map : body_texture, opacity: 1, overdraw : true});
       
        model = new THREE.Object3D();
        
        var body = new THREE.Mesh(sub_body_geometry, sub_body_material);
        body.position.x = 0;
        body.rotation.z = 90 * Math.PI / 180;
        body.name = 'submarine';

        var head = new THREE.Mesh(sub_head_geometry, sub_body_material);
        head.position.y = 20;
        head.name = 'submarine';
        
        var pts = [];
        var detail = .5;
        var radius = 20;
        for(var angle = 0.0; angle < Math.PI ; angle+= detail)
            pts.push(new THREE.Vector3(Math.cos(angle) * radius, 0, Math.sin(angle) * radius));
            
        geometry = new THREE.LatheGeometry(pts, 20);
        
        var front = new THREE.Mesh(geometry, sub_body_material);
        front.position.x = -20;
        front.rotation.y = - 90 * Math.PI / 180;
        front.name = 'submarine';
        
        var back = new THREE.Mesh(geometry, sub_body_material);
        back.position.x = 20;
        back.name = 'submarine';
        back.rotation.y = 90 * Math.PI / 180;

        model.add(body);
        model.add(front);
        model.add(back);
        model.add(head);
	
	scene.add(model);
	loader.model = true;
    }
               
    function draw () {
        if (app.model) {
            draw_model('models/horse.js', 0.3);  
        } else {
            draw_submarine();
        }
    }

    this.draw = function (s) {
        scene = s;
        draw();
    }
    
    this.animate = function () {
        
    }
    
    this.model = function () {
        return model;    
    };
    
    this.rotate_y = function (angle) {
	if (model) {
	    model.rotation.y = angle * Math.PI / 180;
	}
    }
}

function Submarine (r) {
    var frames = [],
        points = [],
        render = r,
        
        model3d = new Submarine3DModel();
        
    var width = sub_size.width,
        height = sub_size.height;
        
    function make_frame(angle) {

	render.update();

	var c = document.createElement('canvas');
            c.width = width;
            c.height = height;
            var ctx = c.getContext('2d');
            ctx.drawImage(render.render().domElement, 0, 0);
            model3d.rotate_y(angle);
            frames[angle] = c;

	    /*
	    var p = render.project();
	    
	    var pl = p.length;
	    
	    for (var i = 0; i < pl; i++) {
		if (p[i] == 1) continue;
		
		for (var j = i + 1; j < pl; j++) {
		    if (p[j] == 1) continue;
		    
		    if (p[j].screen.x == p[i].screen.x && p[j].screen.y == p[i].screen.y) {
			p[j] = 1;
		    }
		}
	    }
	    
	    var points_buffer = [],
		p_i = 0;

	    for (var i = 0; i < pl; i++) {
		if (p[i] != 1) {
		    points_buffer[p_i] = p[i];
		    p_i++;
		}
	    }
	    
	    points_buffer.sort(function (p1, p2) {
                return p1.screen.x - p2.screen.x;
            });
	    
            points[angle] = points_buffer;
	    */
	    
	    
	    var pts = render.project();
	     
	    pts.sort(function (p1, p2) {
                return p1.screen.x - p2.screen.x;
            });
	    
	    points[angle] = pts;
	    
    }
        
    this.load_frames = function () {
        for (var i = 0; i < 360; i++) {
            make_frame(i);
        }
	
	/*
	var obj = {
	    save_history : function () {
		console.log('upload');
	    }
	}
    
	var net = new GraphNet(obj, 1, 'http://sub.loc/server/save.php');
	
	net.send_data(points);
	*/
    }
                
    this.up_down = function (delta) {
        this.deep += delta * -1;
        this.deep = this.deep < sub_position.min ? sub_position.min : this.deep > sub_position.max ? sub_position.max : this.deep;
        this.water_line = this.deep / 10 * -1;
    }
    
    this.load = function () {
        model3d.draw(render.scene());
    }

    this.get_frame = function (a) {
	var angle = a || this.angle;
	
	this.angle = angle;
	
        if (!frames[angle]) {
            make_frame(angle);
        }
        return frames[angle];
    }
    
    this.deep = sub_position.min;
    this.angle = 0;
    this.changed = false;
    
    this.set_angle = function(delta) {
        this.angle += delta;
        this.angle = this.angle > 359 ? 0 : this.angle < 0 ? 359 : this.angle;
	this.changed = true;
    }
    
    this.get_points = function (a) {

	var angle = a || this.angle;
	
        return points[angle];
    }
}







