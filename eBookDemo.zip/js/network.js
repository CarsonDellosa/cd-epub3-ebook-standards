function GraphNet(graph_object, max_buff, server_url) {
    var graph = graph_object,
        buffer = [],
        history = [],
        max_buffer = max_buff,
        url = server_url;
        
    this.send_data = function (status) {
       
        buffer.push(status);
        
        var sl = buffer.length;
        
        if (sl == max_buffer) {
            makeCorsRequest(JSON.stringify(buffer));
        }
    };
    
    function update_data(result) {
        var rl = 0;
        
        if (result != null) {
            rl = result.length;
        }

        for (var i = 0; i < rl; i++) {
            graph.save_history(result[i]);
        }
        buffer = [];
    }
    
    function createCORSRequest(method, url) {
        var xhr = new XMLHttpRequest();
        if ("withCredentials" in xhr) {
            xhr.open(method, url, true);
        } else if (typeof XDomainRequest != "undefined") {
            xhr = new XDomainRequest();
            xhr.open(method, url);
        } else {
            xhr = null;
        }
        
        xhr.withCredentials = true;

        return xhr;
    }
      
    function makeCorsRequest(data) {

        var xhr = createCORSRequest('POST', url);
        if (!xhr) {
            alert('CORS not supported');
            return;
        }

        xhr.onload = function() {
            var msg = xhr.responseText;
            var result = null;
            
            try {
                result = JSON.parse(msg);
            } catch(e) {
                console.log(msg);
            }
            
            update_data(result);
        };
      
        xhr.onerror = function() {
            console.log('CORS error');
        };
      
        xhr.send(data);
    
    }

}
